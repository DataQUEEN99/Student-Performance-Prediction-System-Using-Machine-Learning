# Student Performance Prediction System

## Internship Mini Project

**Student:** Khushi Kumari  
**Project:** Student Performance Prediction System  
**Domain:** Artificial Intelligence / Machine Learning  
**Problem Type:** Supervised Regression  
**Target:** G3 (Final Grade)

## Project Objective

Build a complete Machine Learning workflow to analyze student-related data and predict final academic performance.

## ML Workflow

Data → Cleaning → Analysis → Feature Selection → Training → Testing → Evaluation → Prediction

## Dataset

The project uses the Mathematics student performance dataset (`student-mat.csv`).

- 395 records
- 33 columns
- Target variable: `G3`
- Missing values: 0
- Duplicate rows: 0
- Train/test split: 80/20
- Training records: 316
- Testing records: 79

## Models

1. Linear Regression
2. Random Forest Regressor

## Actual Results

| Model | MAE | RMSE | R² |
|---|---:|---:|---:|
| Random Forest | 1.197 | 2.022 | 0.801 |
| Linear Regression | 1.647 | 2.378 | 0.724 |

**Selected model:** Random Forest

The Random Forest model achieved the best test performance in the submitted Colab notebook.

## Example Prediction

The executed notebook produced an example predicted final grade of **15.53**.

## Top Feature Importance

- G2: 0.796153
- absences: 0.117443
- reason_home: 0.019626
- age: 0.009629
- G1: 0.005478

## Repository Contents

- `notebook/` — executed Jupyter/Colab notebook
- `source_code/` — Python source extracted from notebook
- `dataset/` — project dataset
- `visualizations/` — EDA and model-result figures
- `model_results/` — model metrics and feature importance
- `report/` — detailed project report
- `presentation/` — final presentation
- `requirements.txt` — Python dependencies

## How to Run

1. Open the notebook in Google Colab or Jupyter.
2. Upload the dataset if required.
3. Run cells from top to bottom.
4. Review EDA, model evaluation, and prediction outputs.

## Important Note

G1 and G2 are earlier grades and are strong predictors of G3. Therefore, the model is best interpreted as a demonstration of the Machine Learning workflow rather than a standalone early-warning system.

