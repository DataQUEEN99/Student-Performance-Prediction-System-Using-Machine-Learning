# ================= CELL 2 =================
# Import required libraries

import os
import zipfile
import warnings

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from google.colab import files

warnings.filterwarnings("ignore")

pd.set_option("display.max_columns", None)
pd.set_option("display.max_rows", 100)

sns.set_theme(style="whitegrid")

print("Libraries imported successfully.")

# ================= CELL 3 =================
# Upload and extract the dataset ZIP from your computer

uploaded = files.upload()
uploaded_file = next(iter(uploaded))

print("Uploaded:", uploaded_file)

extract_root = "student_dataset"

with zipfile.ZipFile(uploaded_file, "r") as zip_ref:
    zip_ref.extractall(extract_root)

print("Outer ZIP extracted successfully.")

# Find and extract nested ZIP files if present
inner_zips = []

for root, dirs, file_list in os.walk(extract_root):
    for file_name in file_list:
        if file_name.lower().endswith(".zip"):
            inner_zips.append(os.path.join(root, file_name))

for zip_file in inner_zips:
    nested_folder = os.path.join(
        os.path.dirname(zip_file),
        "nested_data"
    )
    os.makedirs(nested_folder, exist_ok=True)

    with zipfile.ZipFile(zip_file, "r") as zip_ref:
        zip_ref.extractall(nested_folder)

print("Nested ZIP extraction completed.")

# Find student-mat.csv automatically
dataset_path = None

for root, dirs, file_list in os.walk(extract_root):
    for file_name in file_list:
        if file_name.lower() == "student-mat.csv":
            dataset_path = os.path.join(root, file_name)
            break
    if dataset_path is not None:
        break

if dataset_path is None:
    raise FileNotFoundError(
        "student-mat.csv was not found in the uploaded ZIP."
    )

print("Dataset found at:", dataset_path)

# ================= CELL 4 =================
# Load the Mathematics student performance dataset

df = pd.read_csv(dataset_path, sep=";")

print("Dataset loaded successfully.")
print("Rows:", df.shape[0])
print("Columns:", df.shape[1])

display(df.head())

# ================= CELL 6 =================
# Basic dataset information

print("Dataset Shape:", df.shape)

print("\nColumn Names:")
print(df.columns.tolist())

print("\nData Types:")
print(df.dtypes)

print("\nDataset Information:")
df.info()

# ================= CELL 7 =================
# Statistical summary of numerical variables

display(df.describe().T)

# ================= CELL 8 =================
# Categorical variable summary

display(df.describe(include="object").T)

# ================= CELL 9 =================
# Unique values per column

unique_summary = pd.DataFrame({
    "Column": df.columns,
    "Unique Values": df.nunique()
})

display(unique_summary)

# ================= CELL 10 =================
# Display the categories in categorical columns

categorical_columns = df.select_dtypes(include="object").columns.tolist()

for column in categorical_columns:
    print("\n" + "=" * 50)
    print("COLUMN:", column)
    print("=" * 50)
    print(df[column].value_counts())

# ================= CELL 12 =================
# Missing-value analysis

missing_values = df.isnull().sum()

missing_report = pd.DataFrame({
    "Missing Values": missing_values,
    "Missing Percentage": (
        missing_values / len(df) * 100
    ).round(2)
})

display(missing_report)

print("Total Missing Values:", missing_values.sum())

# Duplicate check
duplicate_count = df.duplicated().sum()
print("Duplicate Rows:", duplicate_count)

# ================= CELL 13 =================
# Validate important numerical ranges

print("Age range:", df["age"].min(), "-", df["age"].max())
print("Absence range:", df["absences"].min(), "-", df["absences"].max())

print("\nGrade ranges:")
for column in ["G1", "G2", "G3"]:
    print(f"{column}:", df[column].min(), "to", df[column].max())

invalid_grades = df[
    (df["G1"] < 0) | (df["G1"] > 20) |
    (df["G2"] < 0) | (df["G2"] > 20) |
    (df["G3"] < 0) | (df["G3"] > 20)
]

print("\nInvalid grade records:", len(invalid_grades))

# ================= CELL 14 =================
# Create a clean working copy

clean_df = df.copy()

# Remove exact duplicate rows if any exist
clean_df = clean_df.drop_duplicates().reset_index(drop=True)

print("Original shape:", df.shape)
print("Cleaned shape:", clean_df.shape)
print("Cleaning completed.")

# ================= CELL 15 =================
# Separate categorical and numerical columns

categorical_columns = clean_df.select_dtypes(
    include="object"
).columns.tolist()

numerical_columns = clean_df.select_dtypes(
    exclude="object"
).columns.tolist()

print("Categorical columns:")
print(categorical_columns)

print("\nNumerical columns:")
print(numerical_columns)

# ================= CELL 17 =================
# Distribution of final grades

plt.figure(figsize=(9, 5))
sns.histplot(clean_df["G3"], bins=21, kde=True)

plt.title("Distribution of Final Grades")
plt.xlabel("Final Grade (G3)")
plt.ylabel("Number of Students")
plt.show()

# ================= CELL 18 =================
# Study time versus final grade

plt.figure(figsize=(8, 5))
sns.boxplot(data=clean_df, x="studytime", y="G3")

plt.title("Study Time vs Final Grade")
plt.xlabel("Study Time Category")
plt.ylabel("Final Grade")
plt.show()

# ================= CELL 19 =================
# Previous failures versus final grade

plt.figure(figsize=(8, 5))
sns.boxplot(data=clean_df, x="failures", y="G3")

plt.title("Previous Failures vs Final Grade")
plt.xlabel("Number of Previous Failures")
plt.ylabel("Final Grade")
plt.show()

# ================= CELL 20 =================
# Absences versus final grade

plt.figure(figsize=(9, 5))
sns.scatterplot(
    data=clean_df,
    x="absences",
    y="G3",
    alpha=0.7
)

plt.title("Absences vs Final Grade")
plt.xlabel("Number of Absences")
plt.ylabel("Final Grade")
plt.show()

# ================= CELL 21 =================
# Previous grades versus final grade

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

sns.scatterplot(
    data=clean_df,
    x="G1",
    y="G3",
    ax=axes[0],
    alpha=0.7
)
axes[0].set_title("First Period Grade vs Final Grade")
axes[0].set_xlabel("G1")
axes[0].set_ylabel("G3")

sns.scatterplot(
    data=clean_df,
    x="G2",
    y="G3",
    ax=axes[1],
    alpha=0.7
)
axes[1].set_title("Second Period Grade vs Final Grade")
axes[1].set_xlabel("G2")
axes[1].set_ylabel("G3")

plt.tight_layout()
plt.show()

# ================= CELL 22 =================
# Correlation matrix for numerical variables

correlation_matrix = clean_df.select_dtypes(
    include=np.number
).corr()

plt.figure(figsize=(14, 10))
sns.heatmap(
    correlation_matrix,
    annot=True,
    fmt=".2f",
    cmap="coolwarm",
    center=0
)

plt.title("Correlation Matrix")
plt.show()

# ================= CELL 23 =================
# Correlation of numerical variables with final grade

target_correlation = (
    correlation_matrix["G3"]
    .sort_values(ascending=False)
)

display(target_correlation.to_frame(name="Correlation"))

# ================= CELL 25 =================
# Separate features and target

X = clean_df.drop(columns=["G3"])
y = clean_df["G3"]

print("Feature matrix shape:", X.shape)
print("Target shape:", y.shape)
print("Target variable: G3")

# ================= CELL 26 =================
from sklearn.model_selection import train_test_split

# Split the dataset into training and testing sets

X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.20,
    random_state=42
)

print("Training records:", len(X_train))
print("Testing records:", len(X_test))

# ================= CELL 27 =================
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder

# Identify feature types after the train/test split

categorical_features = X_train.select_dtypes(
    include="object"
).columns.tolist()

numerical_features = X_train.select_dtypes(
    exclude="object"
).columns.tolist()

preprocessor = ColumnTransformer(
    transformers=[
        (
            "categorical",
            OneHotEncoder(
                handle_unknown="ignore",
                drop="first"
            ),
            categorical_features
        ),
        (
            "numerical",
            "passthrough",
            numerical_features
        )
    ]
)

print("Categorical features:", len(categorical_features))
print("Numerical features:", len(numerical_features))
print("Preprocessing pipeline created.")

# ================= CELL 29 =================
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LinearRegression

linear_model = Pipeline(
    steps=[
        ("preprocessing", preprocessor),
        ("model", LinearRegression())
    ]
)

linear_model.fit(X_train, y_train)

print("Linear Regression training completed.")

# ================= CELL 30 =================
from sklearn.ensemble import RandomForestRegressor

random_forest_model = Pipeline(
    steps=[
        ("preprocessing", preprocessor),
        (
            "model",
            RandomForestRegressor(
                n_estimators=300,
                random_state=42,
                min_samples_leaf=2
            )
        )
    ]
)

random_forest_model.fit(X_train, y_train)

print("Random Forest training completed.")

# ================= CELL 32 =================
# Generate predictions on unseen test data

linear_predictions = linear_model.predict(X_test)
rf_predictions = random_forest_model.predict(X_test)

print("Predictions generated successfully.")

# ================= CELL 33 =================
from sklearn.metrics import (
    mean_absolute_error,
    mean_squared_error,
    r2_score
)

def evaluate_model(model_name, actual, predicted):
    mae = mean_absolute_error(actual, predicted)
    rmse = np.sqrt(mean_squared_error(actual, predicted))
    r2 = r2_score(actual, predicted)

    return {
        "Model": model_name,
        "MAE": round(mae, 3),
        "RMSE": round(rmse, 3),
        "R2 Score": round(r2, 3)
    }

results = pd.DataFrame([
    evaluate_model(
        "Linear Regression",
        y_test,
        linear_predictions
    ),
    evaluate_model(
        "Random Forest",
        y_test,
        rf_predictions
    )
])

display(results)

# ================= CELL 34 =================
# Compare the models

results_sorted = results.sort_values(
    by="RMSE"
).reset_index(drop=True)

display(results_sorted)

best_model_name = results_sorted.loc[0, "Model"]

print("Best model based on lowest RMSE:", best_model_name)

# ================= CELL 35 =================
# Visualize model performance

plt.figure(figsize=(9, 5))

sns.barplot(
    data=results,
    x="Model",
    y="RMSE"
)

plt.title("Model Comparison - RMSE")
plt.xlabel("Model")
plt.ylabel("RMSE")
plt.show()

# ================= CELL 36 =================
# Select the best-performing model

if best_model_name == "Random Forest":
    best_model = random_forest_model
    best_predictions = rf_predictions
else:
    best_model = linear_model
    best_predictions = linear_predictions

print("Selected model:", best_model_name)

# ================= CELL 37 =================
# Actual versus predicted final grades

plt.figure(figsize=(8, 6))

plt.scatter(
    y_test,
    best_predictions,
    alpha=0.7
)

min_value = min(y_test.min(), best_predictions.min())
max_value = max(y_test.max(), best_predictions.max())

plt.plot(
    [min_value, max_value],
    [min_value, max_value],
    linestyle="--"
)

plt.xlabel("Actual Final Grade")
plt.ylabel("Predicted Final Grade")
plt.title(f"Actual vs Predicted Grades - {best_model_name}")

plt.show()

# ================= CELL 38 =================
# Prediction error distribution

prediction_errors = y_test - best_predictions

plt.figure(figsize=(9, 5))

sns.histplot(
    prediction_errors,
    bins=20,
    kde=True
)

plt.axvline(0, linestyle="--")

plt.title("Distribution of Prediction Errors")
plt.xlabel("Actual - Predicted")
plt.ylabel("Frequency")

plt.show()

# ================= CELL 40 =================
# Feature importance from Random Forest

rf_preprocessor = random_forest_model.named_steps["preprocessing"]
rf_model = random_forest_model.named_steps["model"]

feature_names = rf_preprocessor.get_feature_names_out()
importance_values = rf_model.feature_importances_

feature_importance = pd.DataFrame({
    "Feature": feature_names,
    "Importance": importance_values
}).sort_values(
    by="Importance",
    ascending=False
)

display(feature_importance.head(15))

# ================= CELL 41 =================
# Visualize the most important features

top_features = feature_importance.head(15).sort_values(
    by="Importance"
)

plt.figure(figsize=(10, 7))

sns.barplot(
    data=top_features,
    x="Importance",
    y="Feature"
)

plt.title("Top Features Used by Random Forest")
plt.xlabel("Importance")
plt.ylabel("Feature")

plt.show()

# ================= CELL 43 =================
# Prediction function for a new student

def predict_student(model, student_data):
    student_df = pd.DataFrame([student_data])
    prediction = model.predict(student_df)[0]

    # Final grade is expected to be between 0 and 20
    prediction = np.clip(prediction, 0, 20)

    return round(float(prediction), 2)

# ================= CELL 44 =================
# Example student

sample_student = {
    "school": "GP",
    "sex": "F",
    "age": 17,
    "address": "U",
    "famsize": "GT3",
    "Pstatus": "T",
    "Medu": 4,
    "Fedu": 4,
    "Mjob": "teacher",
    "Fjob": "services",
    "reason": "course",
    "guardian": "mother",
    "traveltime": 2,
    "studytime": 3,
    "failures": 0,
    "schoolsup": "yes",
    "famsup": "yes",
    "paid": "no",
    "activities": "yes",
    "nursery": "yes",
    "higher": "yes",
    "internet": "yes",
    "romantic": "no",
    "famrel": 4,
    "freetime": 3,
    "goout": 3,
    "Dalc": 1,
    "Walc": 1,
    "health": 5,
    "absences": 4,
    "G1": 14,
    "G2": 15
}

predicted_grade = predict_student(
    best_model,
    sample_student
)

print("Student Performance Prediction")
print("-" * 40)
print("Predicted Final Grade:", predicted_grade)

# ================= CELL 46 =================
# Save model evaluation results

results_sorted.to_csv(
    "model_results.csv",
    index=False
)

print("Saved: model_results.csv")

# ================= CELL 47 =================
# Save feature importance results

feature_importance.to_csv(
    "feature_importance.csv",
    index=False
)

print("Saved: feature_importance.csv")

# ================= CELL 48 =================
# Save the cleaned dataset used for analysis

clean_df.to_csv(
    "student_performance_clean.csv",
    index=False
)

print("Saved: student_performance_clean.csv")

# ================= CELL 50 =================
print("=" * 60)
print("STUDENT PERFORMANCE PREDICTION SYSTEM")
print("=" * 60)

print("\nDataset")
print("Rows:", len(clean_df))
print("Columns:", len(clean_df.columns))

print("\nTarget")
print("G3 - Final Grade")

print("\nMachine Learning Type")
print("Supervised Regression")

print("\nTraining Samples:", len(X_train))
print("Testing Samples:", len(X_test))

print("\nModel Results")
display(results_sorted)

print("\nSelected Model:", best_model_name)

print("\nCompleted ML Workflow:")
print("Data -> Cleaning -> Analysis -> Feature Selection")
print("-> Training -> Testing -> Evaluation -> Prediction")

print("\nProject completed successfully.")
